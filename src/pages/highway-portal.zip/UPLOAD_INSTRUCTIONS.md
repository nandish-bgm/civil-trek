# Highway Design Portal — upload guide

Repo: nandish-bgm/civil-trek

## What's in this zip

| File | Action | Where in repo |
|---|---|---|
| `src/data/highwayData.js` | **Add (new)** | upload into `src/data/` |
| `src/pages/HighwayPortal.jsx` | **Add (new)** | upload into `src/pages/` |
| `src/App.jsx` | **Replace** | overwrites `src/App.jsx` |
| `src/components/Navbar.jsx` | **Replace** | overwrites `src/components/Navbar.jsx` |
| `HOME_CARD_SNIPPET.jsx` | Optional | copy the snippet into your Home.jsx |
| `UPLOAD_INSTRUCTIONS.md` | Reference only | do NOT upload |

So the portal itself is **4 files**: 2 new + 2 replacements. The other two are docs.

## Steps (GitHub web UI)

1. `src/data/` → Add file → Upload files → drag `highwayData.js`.
2. `src/pages/` → Add file → Upload files → drag `HighwayPortal.jsx`.
3. `src/App.jsx` → drag the new `App.jsx` in (or edit and paste) → commit.
4. `src/components/Navbar.jsx` → same → commit.

## Important — before replacing App.jsx / Navbar.jsx

These two replacements are built from the versions in your project files. If you've
edited either since then, DON'T overwrite blindly — instead just add these lines to
your live versions:

**App.jsx** — add the import:
```jsx
import HighwayPortal from './pages/HighwayPortal.jsx';
```
and add the route inside `<Routes>`:
```jsx
<Route path="/tools/highway" element={<HighwayPortal />} />
```

**Navbar.jsx** — add one link next to the Calculator link:
```jsx
<Link to="/tools/highway" className={linkClass('/tools/highway')}>Highway</Link>
```

## Deploy

Commit + push. Vercel auto-builds on push — nothing to configure.
No new npm packages, no env vars, no Supabase changes.
Live at: /tools/highway
