// OPTIONAL — paste this into src/pages/Home.jsx to add a card that links
// to the Highway portal. Make sure Home.jsx imports Link from react-router-dom.
//
//   import { Link } from 'react-router-dom';
//
// Then drop this <Link> wherever your feature cards / grid are:

<Link
  to="/tools/highway"
  className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm hover:border-orange-400 transition-colors block"
>
  <div className="text-3xl mb-2">🛣️</div>
  <h3 className="font-semibold text-gray-900">Highway Design Portal</h3>
  <p className="text-sm text-gray-500 mt-1">
    IRC cross-sections, camber, gradients and geometric standards.
  </p>
</Link>
