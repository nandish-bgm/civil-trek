import { useState } from 'react';
import { ROAD_CLASSES, CAMBER, GRADIENTS, CROSS_SECTION, SUPERELEVATION } from '../data/highwayData.js';

function CrossSectionSVG({ hovered, setHovered }) {
  const parts = { drain: '#60a5fa', shoulder: '#d1d5db', carriageway: '#4b5563', median: '#86efac', camber: '#f59e0b', row: '#e5e7eb' };
  const hl = (k) => (hovered === k ? 1 : hovered ? 0.35 : 1);

  return (
    <svg viewBox="0 0 700 260" className="w-full">
      <rect x="20" y="180" width="660" height="14" fill={parts.row} opacity={hl('row')}
        onMouseEnter={() => setHovered('row')} onMouseLeave={() => setHovered(null)} />
      <text x="350" y="191" textAnchor="middle" fontSize="9" fill="#374151">Right of Way (RoW)</text>
      <polygon points="20,180 120,120 580,120 680,180" fill="#f3f4f6" stroke="#e5e7eb" />
      <path d="M120,120 l-14,14 l14,0 z" fill={parts.drain} opacity={hl('drain')}
        onMouseEnter={() => setHovered('drain')} onMouseLeave={() => setHovered(null)} />
      <path d="M580,120 l14,14 l-14,0 z" fill={parts.drain} opacity={hl('drain')}
        onMouseEnter={() => setHovered('drain')} onMouseLeave={() => setHovered(null)} />
      <rect x="120" y="112" width="70" height="8" fill={parts.shoulder} opacity={hl('shoulder')}
        onMouseEnter={() => setHovered('shoulder')} onMouseLeave={() => setHovered(null)} />
      <rect x="510" y="112" width="70" height="8" fill={parts.shoulder} opacity={hl('shoulder')}
        onMouseEnter={() => setHovered('shoulder')} onMouseLeave={() => setHovered(null)} />
      <polygon points="190,112 330,112 330,108 190,110" fill={parts.carriageway} opacity={hl('carriageway')}
        onMouseEnter={() => setHovered('carriageway')} onMouseLeave={() => setHovered(null)} />
      <polygon points="370,108 510,112 510,112 370,112" fill={parts.carriageway} opacity={hl('carriageway')}
        onMouseEnter={() => setHovered('carriageway')} onMouseLeave={() => setHovered(null)} />
      <rect x="330" y="100" width="40" height="12" fill={parts.median} opacity={hl('median')}
        onMouseEnter={() => setHovered('median')} onMouseLeave={() => setHovered(null)} />
      <g opacity={hl('camber')} onMouseEnter={() => setHovered('camber')} onMouseLeave={() => setHovered(null)}>
        <line x1="260" y1="95" x2="200" y2="105" stroke={parts.camber} strokeWidth="2" markerEnd="url(#arr)" />
        <line x1="440" y1="95" x2="500" y2="105" stroke={parts.camber} strokeWidth="2" markerEnd="url(#arr)" />
        <text x="350" y="88" textAnchor="middle" fontSize="9" fill={parts.camber}>camber ↘ ↙</text>
      </g>
      <defs>
        <marker id="arr" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
          <path d="M0,0 L6,3 L0,6 z" fill={parts.camber} />
        </marker>
      </defs>
      <text x="155" y="145" textAnchor="middle" fontSize="8" fill="#6b7280">shoulder</text>
      <text x="545" y="145" textAnchor="middle" fontSize="8" fill="#6b7280">shoulder</text>
      <text x="260" y="130" textAnchor="middle" fontSize="8" fill="#6b7280">lane</text>
      <text x="440" y="130" textAnchor="middle" fontSize="8" fill="#6b7280">lane</text>
    </svg>
  );
}

function GradientVisualizer() {
  const [grade, setGrade] = useState(3.3);
  const angle = Math.atan(grade / 100) * (180 / Math.PI);
  const ratio = grade > 0 ? Math.round(100 / grade) : 0;
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <label className="text-sm font-medium text-gray-700">Gradient: {grade.toFixed(1)}% (1 in {ratio})</label>
        <span className="text-xs text-gray-500">slope angle ≈ {angle.toFixed(1)}°</span>
      </div>
      <input type="range" min="0" max="10" step="0.1" value={grade}
        onChange={(e) => setGrade(+e.target.value)} className="w-full accent-orange-600" />
      <svg viewBox="0 0 400 140" className="w-full mt-3">
        <line x1="20" y1="120" x2="380" y2="120" stroke="#e5e7eb" strokeWidth="2" />
        <line x1="20" y1="120" x2="380" y2={120 - (grade / 100) * 360} stroke="#D85A30" strokeWidth="4" />
        <circle cx="380" cy={120 - (grade / 100) * 360} r="6" fill="#D85A30" />
        <text x="200" y="135" textAnchor="middle" fontSize="10" fill="#6b7280">horizontal distance</text>
      </svg>
    </div>
  );
}

const card = 'bg-white border border-gray-200 rounded-xl p-5 shadow-sm';

export default function HighwayPortal() {
  const [selected, setSelected] = useState(ROAD_CLASSES[0]);
  const [hovered, setHovered] = useState(null);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Road / Highway Design Portal</h1>
        <p className="text-sm text-gray-500 mt-1">
          Interactive reference for highway cross-sections, camber, gradients and geometric standards (IRC).
        </p>
      </div>

      <div className={card}>
        <h2 className="text-sm font-semibold text-gray-800 mb-3">Typical Divided Highway Cross-Section</h2>
        <CrossSectionSVG hovered={hovered} setHovered={setHovered} />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2 mt-4">
          {CROSS_SECTION.map((el) => (
            <div key={el.key}
              onMouseEnter={() => setHovered(el.key)} onMouseLeave={() => setHovered(null)}
              className={`p-3 rounded-lg border cursor-default transition-colors ${
                hovered === el.key ? 'bg-orange-50 border-orange-300' : 'bg-gray-50 border-gray-200'}`}>
              <p className="text-sm font-medium text-gray-800">{el.label}</p>
              <p className="text-xs text-gray-500 mt-0.5">{el.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <div className={card}>
        <h2 className="text-sm font-semibold text-gray-800 mb-3">Road Classification (IRC:73)</h2>
        <div className="flex flex-wrap gap-2 mb-4">
          {ROAD_CLASSES.map((rc) => (
            <button key={rc.id} onClick={() => setSelected(rc)}
              className={`py-2 px-3 rounded-lg text-sm font-medium border transition-colors ${
                selected.id === rc.id ? 'bg-orange-600 text-white border-orange-600'
                : 'bg-white text-gray-700 border-gray-300 hover:border-orange-400'}`}>
              {rc.name}
            </button>
          ))}
        </div>
        <div className="grid sm:grid-cols-2 gap-x-8 gap-y-2 text-sm">
          {[['Reference', selected.ref], ['Design speed', selected.designSpeed],
            ['Lane width', selected.laneWidth], ['Carriageway', selected.carriageway],
            ['Shoulder', selected.shoulder]].map(([k, v]) => (
            <div key={k} className="flex justify-between border-b border-gray-100 py-1.5">
              <span className="text-gray-500">{k}</span>
              <span className="text-gray-800 font-medium text-right">{v}</span>
            </div>
          ))}
        </div>
        <p className="text-xs text-gray-500 mt-3">{selected.notes}</p>
      </div>

      <div className={card}>
        <h2 className="text-sm font-semibold text-gray-800 mb-3">Gradient Visualizer</h2>
        <GradientVisualizer />
        <div className="overflow-x-auto mt-4">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-gray-500 border-b border-gray-200">
                <th className="py-2 pr-4">Terrain</th><th className="py-2 pr-4">Ruling</th>
                <th className="py-2 pr-4">Limiting</th><th className="py-2">Exceptional</th>
              </tr>
            </thead>
            <tbody>
              {GRADIENTS.map((g) => (
                <tr key={g.terrain} className="border-b border-gray-100">
                  <td className="py-2 pr-4 text-gray-700">{g.terrain}</td>
                  <td className="py-2 pr-4 text-gray-800">{g.ruling}</td>
                  <td className="py-2 pr-4 text-gray-800">{g.limiting}</td>
                  <td className="py-2 text-gray-800">{g.exceptional}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className={card}>
          <h2 className="text-sm font-semibold text-gray-800 mb-3">Camber (Cross-Slope)</h2>
          {CAMBER.map((c) => (
            <div key={c.surface} className="flex justify-between border-b border-gray-100 py-2 text-sm">
              <span className="text-gray-600 pr-3">{c.surface}</span>
              <span className="text-gray-800 font-medium text-right whitespace-nowrap">{c.value}</span>
            </div>
          ))}
        </div>
        <div className={card}>
          <h2 className="text-sm font-semibold text-gray-800 mb-3">Superelevation</h2>
          <p className="text-sm text-gray-700 mb-2">Maximum: <span className="font-medium">{SUPERELEVATION.max}</span></p>
          <div className="bg-gray-900 text-orange-300 font-mono text-sm rounded-lg px-4 py-3 text-center">
            {SUPERELEVATION.formula}
          </div>
          <p className="text-xs text-gray-500 mt-2">{SUPERELEVATION.note}</p>
        </div>
      </div>

      <p className="text-xs text-gray-400">
        Educational reference based on IRC guidelines. Verify all values against the current IRC codes before design use.
      </p>
    </div>
  );
}
